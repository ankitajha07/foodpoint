# BIT-O-PATH
Food Points in the BIT Campus AND There prediced crowd and Menu Details.
Enjoy Hassle Free Outings..!!

Link : https://adityaarc.github.io/bitopath/

